this only exists to make github happy lmao

If you do, by some chance, find a serious issue, DM me on Discord.
