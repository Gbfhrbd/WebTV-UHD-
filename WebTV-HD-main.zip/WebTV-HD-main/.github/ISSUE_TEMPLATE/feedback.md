---
name: Feedback
about: Have feedback?
title: "[Feedback] "
labels: enhancement
assignees: SKCro

---

> **What feature or aspect are you leaving feedback about?**


> **What do you like about it?**


> **What do you dislike about it?**


> **If you dislike it, what would you like to see changed about it?**


> **Is there anything else you'd like to mention?**
